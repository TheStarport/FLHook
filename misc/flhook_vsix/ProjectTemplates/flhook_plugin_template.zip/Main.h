#pragma once

#include <FLHook.h>
#include <plugin.h>

extern ReturnCode returncode;